"""Select2 support for DAL."""

default_app_config = 'dal_select2.apps.DefaultApp'
