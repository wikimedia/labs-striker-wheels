"""QuerySetSequence support for DAL."""
