version = (1, 2, 8)
version_string = '.'.join(map(str, version))
