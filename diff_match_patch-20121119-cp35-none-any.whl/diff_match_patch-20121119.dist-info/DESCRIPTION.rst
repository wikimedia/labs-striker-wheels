================
diff-match-patch
================

Documentation on the Google site:

http://code.google.com/p/google-diff-match-patch/

See README.original.txt for the original README.

This is an unofficial package of the Python versions for PyPI, by
Luke Plant http://lukeplant.me.uk/

See https://bitbucket.org/spookylukey/diff-match-patch for packaging issues.





Version 20121119
----------------
Upstream release

Version 20120106
----------------
Upstream release

Version 20111010
----------------
Upstream release

Version 20110725.1
------------------
* Python 3 packaging bug (python3 directory excluded)
* Other packaging bugs (extra files included).


Version 20110725
----------------
Initial PyPI package


