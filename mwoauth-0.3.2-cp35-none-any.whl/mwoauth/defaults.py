USER_AGENT = "python-mwoauth default user agent"
