"""DAL's Select2 and django-tagging extension."""
