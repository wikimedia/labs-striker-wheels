class OAuthException(Exception):
    pass
