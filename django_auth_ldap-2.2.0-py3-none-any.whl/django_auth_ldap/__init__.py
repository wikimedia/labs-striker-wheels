VERSION = (2, 2, 0)
__version__ = ".".join(str(i) for i in VERSION)

# Deprecated. Use VERSION and __version__ instead.
version = VERSION
version_string = __version__
