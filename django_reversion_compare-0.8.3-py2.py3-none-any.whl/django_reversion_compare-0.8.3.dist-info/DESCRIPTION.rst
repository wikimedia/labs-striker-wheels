========================
django-reversion-compare
========================

**django-reversion-compare** is an extension to `django-reversion <https://github.com/etianen/django-reversion/>`_ that provides a history compare view to compare two versions of a model which is under reversion.

Comparing model versions is not a easy task. Maybe there are different view how this should looks like.
This project will gives you a generic way to see whats has been changed.

Many parts are customizable by overwrite methods or subclassing, see above.

+--------------------------------------+--------------------------------------------------------------------+
| |Build Status on travis-ci.org|      | `travis-ci.org/jedie/django-reversion-compare`_                    |
+--------------------------------------+--------------------------------------------------------------------+
| |Coverage Status on coveralls.io|    | `coveralls.io/r/jedie/django-reversion-compare`_                   |
+--------------------------------------+--------------------------------------------------------------------+
| |Coverage Status on codecov.io|      | `codecov.io/gh/jedie/django-reversion-compare`_                    |
+--------------------------------------+--------------------------------------------------------------------+
| |Requirements Status on requires.io| | `requires.io/github/jedie/django-reversion-compare/requirements/`_ |
+--------------------------------------+--------------------------------------------------------------------+

.. |Build Status on travis-ci.org| image:: https://travis-ci.org/jedie/django-reversion-compare.svg
.. _travis-ci.org/jedie/django-reversion-compare: https://travis-ci.org/jedie/django-reversion-compare/
.. |Coverage Status on coveralls.io| image:: https://coveralls.io/repos/jedie/django-reversion-compare/badge.svg
.. _coveralls.io/r/jedie/django-reversion-compare: https://coveralls.io/r/jedie/django-reversion-compare
.. |Coverage Status on codecov.io| image:: https://codecov.io/gh/jedie/django-reversion-compare/branch/master/graph/badge.svg
.. _codecov.io/gh/jedie/django-reversion-compare: https://codecov.io/gh/jedie/django-reversion-compare
.. |Requirements Status on requires.io| image:: https://requires.io/github/jedie/django-reversion-compare/requirements.svg
.. _requires.io/github/jedie/django-reversion-compare/requirements/: https://requires.io/github/jedie/django-reversion-compare/requirements/

------------
Installation
------------

Just use:

::

    pip install django-reversion-compare

Optionally you can install `google-diff-match-patch <https://code.google.com/p/google-diff-match-patch/>`_, otherwise difflib would be used. The easiest way is to use the unofficial package `diff-match-patch <http://pypi.python.org/pypi/diff-match-patch/>`_, e.g.:

::

    pip install diff-match-patch

Setup
=====

Add **reversion_compare** to **INSTALLED_APPS** in your settings.py, e.g.:

::

    INSTALLED_APPS = (
        'django...',
        ...
        'reversion', # https://github.com/etianen/django-reversion
        'reversion_compare', # https://github.com/jedie/django-reversion-compare
        ...
    )

    # Add reversion models to admin interface:
    ADD_REVERSION_ADMIN=True

Usage
=====

Inherit from **CompareVersionAdmin** instead of **VersionAdmin** to get the comparison feature.

admin.py e.g.:

::

    from django.contrib import admin
    from reversion_compare.admin import CompareVersionAdmin

    from my_app.models import ExampleModel

    class ExampleModelAdmin(CompareVersionAdmin):
        pass

    admin.site.register(ExampleModel, ExampleModelAdmin)

If you're using an existing third party app, then you can add patch django-reversion-compare into
its admin class by using the **reversion_compare.helpers.patch_admin()** method. For example, to add
version control to the built-in User model:

::

    from reversion_compare.helpers import patch_admin

    patch_admin(User)

e.g.: Add django-cms Page model:

::

    from cms.models.pagemodel import Page
    from reversion_compare.helpers import patch_admin


    # Patch django-cms Page Model to add reversion-compare functionality:
    patch_admin(Page)

Customize
=========

It's possible to change the look for every field or for a entire field type.
You must only define a methods to your admin class with this name scheme:

*  ``"compare_%s" % field_name`` 

*  ``"compare_%s" % field.get_internal_type()`` 

If there is no method with this name scheme, the ``fallback_compare()`` method will be used.

An example for specifying a compare method for a model field by name:

::

    class YourAdmin(CompareVersionAdmin):
        def compare_foo_bar(self, obj_compare):
            """ compare the foo_bar model field """
            return "%r <-> %r" % (obj_compare.value1, obj_compare.value2)

and example using **patch_admin** with custom version admin class:

::

    patch_admin(User, AdminClass=YourAdmin)

----------------
Class Based View
----------------

Beyond the Admin views, you can also create a Class Based View for displaying and comparing version
differences. This is a single class-based-view that either displays the list of versions to select
for an object or displays both the versions **and** their differences (if the versions to be compared
have been selected). This class can be used just like a normal DetailView:

Inherit from it in your class and add a model (or queryset), for example:

::

    from reversion_compare.views import HistoryCompareDetailView

    class SimpleModelHistoryCompareView(HistoryCompareDetailView):
        model = SimpleModel

Then, assign that CBV to a url, for example:

::

    url(r'^test_view/(?P<pk>\d+)$', views.SimpleModelHistoryCompareView.as_view() ),

Last step, you need to create a template to display both the version select form and
the changes part (if the form is submitted). An example template is the following:

::

    <style type="text/css">
    /* minimal style for the diffs */
    del, ins {
        color: #000;
        text-decoration: none;
    }
    del { background-color: #ffe6e6; }
    ins { background-color: #e6ffe6; }
    sup.follow { color: #5555ff; }
    </style>

    {% include "reversion-compare/action_list_partial.html"  %}
    {% if request.GET.version_id1 %}
        {% include "reversion-compare/compare_partial.html"  %}
        {% include "reversion-compare/compare_links_partial.html"  %}
    {% endif %}

Beyond the styling, you should include:

* reversion-compare/action_list_partial.html partial template to display the version select form

* reversion-compare/compare_partial.html partial template to display the actual version

* reversion-compare/compare_links_partial.html to include previous/next comparison links

compare_partial.html and compare_links_partial.html will show the compare-related information
so it's better to display them only when the select-versions-tocompare-form has been submitted.
If you want more control on the appearence of your templates you can check the above partials
to understand how the availabble context variables are used and override them completely.

-----------
Screenshots
-----------

Here some screenshots of django-reversion-compare:

----

How to select the versions to compare:

|django-reversion-compare_v0_1_0-01.png|

.. |django-reversion-compare_v0_1_0-01.png| image:: http://www.pylucid.org/static/pylucid.org/screenshots_PyLucid/django-reversion/django-reversion-compare_v0_1_0-01.png

----

from **v0.1.0**: DateTimeField compare (last update), TextField compare (content) with small changes and a ForeignKey compare (child model instance was added):

|django-reversion-compare_v0_1_0-02.png|

.. |django-reversion-compare_v0_1_0-02.png| image:: http://www.pylucid.org/static/pylucid.org/screenshots_PyLucid/django-reversion/django-reversion-compare_v0_1_0-02.png

----

from **v0.1.0**: Same as above, but the are more lines changed in TextField and the ForeignKey relation was removed:

|django-reversion-compare_v0_1_0-03.png|

.. |django-reversion-compare_v0_1_0-03.png| image:: http://www.pylucid.org/static/pylucid.org/screenshots_PyLucid/django-reversion/django-reversion-compare_v0_1_0-03.png

----

Example screenshot from **v0.3.0**: a many-to-many field compare (friends, hobbies):

|django-reversion-compare_v0_3_0-01.png|

.. |django-reversion-compare_v0_3_0-01.png| image:: http://www.pylucid.org/static/pylucid.org/screenshots_PyLucid/django-reversion/django-reversion-compare_v0_3_0-01.png

* In the first line, the m2m object has been changed.

* line 2: A m2m object was deleted

* line 3: A m2m object was removed from this entry (but not deleted)

* line 4: This m2m object has not changed

-------------
running tests
-------------

Run all tests in all environment combinations via tox:

::

    $ python3 setup.py tox

Run all tests in current environment via pytest:

::

    $ python3 setup.py test

Helpfull for writing and debugging unittests is to run a local test server with the same data.
e.g.:

::

    ~$ cd path/to/django-reversion-compare/
    /django-reversion-compare$ ./run_testserver.py

**migration** will be run and a superuser will be created. Username: **test** Password: **12345678**

---------------------
Version compatibility
---------------------

+-------------------+------------------+-------------------+------------------------------------------------+
| Reversion-Compare | django-reversion | Django            | Python                                         |
+===================+==================+===================+================================================+
| >=v0.8.3          | v2.0             | v1.8, 1.11        | v3.5, v3.6, pypy3                              |
+-------------------+------------------+-------------------+------------------------------------------------+
| v0.8.x            | v2.0             | v1.8, v1.10, 1.11 | v2.7, v3.4, v3.5, v3.6 (only with Django 1.11) |
+-------------------+------------------+-------------------+------------------------------------------------+
| >=v0.7.2          | v2.0             | v1.8, v1.9, v1.10 | v2.7, v3.4, v3.5                               |
+-------------------+------------------+-------------------+------------------------------------------------+
| v0.7.x            | v2.0             | v1.8, v1.9        | v2.7, v3.4, v3.5                               |
+-------------------+------------------+-------------------+------------------------------------------------+
| v0.6.x            | v1.9, v1.10      | v1.8, v1.9        | v2.7, v3.4, v3.5                               |
+-------------------+------------------+-------------------+------------------------------------------------+
| >=v0.5.2          | v1.9             | v1.7, v1.8        | v2.7, v3.4                                     |
+-------------------+------------------+-------------------+------------------------------------------------+
| >=v0.4            | v1.8             | v1.7              | v2.7, v3.4                                     |
+-------------------+------------------+-------------------+------------------------------------------------+
| <v0.4             | v1.6             | v1.4              | v2.7                                           |
+-------------------+------------------+-------------------+------------------------------------------------+

These are the unittests variants. See also: `/.travis.yml <https://github.com/jedie/django-reversion-compare/blob/master/.travis.yml>`_
Maybe other versions are compatible, too.

---------
Changelog
---------

* v0.8.3 - 21.12.2017 `compare v0.8.2...master <https://github.com/jedie/django-reversion-compare/compare/v0.8.2...master>`_ 

    * refactor travis/tox/pytest/coverage stuff

    * Tests can be run via ``python3 setup.py tox`` and/or ``python3 setup.py test``

    * Test also with pypy3 on Travis CI.

* `v0.8.2 - 06.12.2017 <https://github.com/jedie/django-reversion-compare/compare/v0.8.1...v0.8.2>`_:

    * `Change ForeignKey relation compare <https://github.com/jedie/django-reversion-compare/pull/100>`_ contributed by `alaruss <https://github.com/alaruss>`_

    * `Work around a type error triggered by taggit <https://github.com/jedie/django-reversion-compare/pull/86>`_ contributed by `Athemis <https://github.com/Athemis>`_

    * minor code changes

* `v0.8.1 - 02.10.2017 <https://github.com/jedie/django-reversion-compare/compare/v0.8.0...v0.8.1>`_:

    * `Add added polish translation <https://github.com/jedie/django-reversion-compare/pull/99>`_ contributed by `w4rri0r3k <https://github.com/w4rri0r3k>`_

    * Bugfix "Django>=1.11" in setup.py

* `v0.8.0 - 17.08.2017 <https://github.com/jedie/django-reversion-compare/compare/v0.7.5...v0.8.0>`_:

    * Run tests with Django v1.11 and drop tests with Django v1.9

* `v0.7.5 - 24.04.2017 <https://github.com/jedie/django-reversion-compare/compare/v0.7.4...v0.7.5>`_:

    * `Using the 'render' function to ensure the execution of context processors properly <https://github.com/jedie/django-reversion-compare/pull/90>`_ contributed by `Rodrigo Pinheiro Marques de Araújo <https://github.com/fenrrir>`_

* `v0.7.4 - 10.04.2017 <https://github.com/jedie/django-reversion-compare/compare/v0.7.3...v0.7.4>`_:

    * Bugfix for Python 2: `compare unicode instead of bytes <https://github.com/jedie/django-reversion-compare/issues/89>`_ contributed by `Maksim Iakovlev <https://github.com/lampslave>`_

    * `remove 'Django20Warning' <https://github.com/jedie/django-reversion-compare/pull/88>`_ contributed by `Hugo Tácito <https://github.com/hugotacito>`_

    * `Add 'Finnish' localisations <https://github.com/jedie/django-reversion-compare/pull/87>`_ contributed by `Olli-Pekka Puolitaival <https://github.com/OPpuolitaival>`_

* `v0.7.3 - 08.02.2017 <https://github.com/jedie/django-reversion-compare/compare/v0.7.2...v0.7.3>`_:

    * `Fix case when model has template field which is ForeignKey <https://github.com/jedie/django-reversion-compare/pull/85>`_ contributed by `Lagovas <https://github.com/Lagovas>`_

* `v0.7.2 - 20.10.2016 <https://github.com/jedie/django-reversion-compare/compare/v0.7.1...v0.7.2>`_:

    * Add Django v1.10 support

* `v0.7.1 - 29.08.2016 <https://github.com/jedie/django-reversion-compare/compare/v0.7.0...v0.7.1>`_:

    * `Fix #79: missing import if **ADD_REVERSION_ADMIN != True** <https://github.com/jedie/django-reversion-compare/issues/79>`_

* `v0.7.0 - 25.08.2016 <https://github.com/jedie/django-reversion-compare/compare/v0.6.3...v0.7.0>`_:

    * `support only django-reversion >= 2.0 <https://github.com/jedie/django-reversion-compare/pull/76>`_ based on a contribution by `mshannon1123 <https://github.com/jedie/django-reversion-compare/pull/73>`_

    * remove internal **reversion_api**

    * Use tox

* `v0.6.3 - 14.06.2016 <https://github.com/jedie/django-reversion-compare/compare/v0.6.2...v0.6.3>`_:

    * `Remove unused and deprecated patters <https://github.com/jedie/django-reversion-compare/pull/69>`_ contributed by `codingjoe <https://github.com/codingjoe>`_

    * `Fix django 1.10 warning #66 <https://github.com/jedie/django-reversion-compare/pull/66>`_ contributed by `pypetey <https://github.com/pypetey>`_

* `v0.6.2 - 27.04.2016 <https://github.com/jedie/django-reversion-compare/compare/v0.6.1...v0.6.2>`_:

    * `Added choices field representation #63 <https://github.com/jedie/django-reversion-compare/pull/63>`_ contributed by `amureki <https://github.com/amureki>`_

    * `Check if related model has an integer as pk for ManyToMany fields. #64 <https://github.com/jedie/django-reversion-compare/pull/64>`_ contributed by `logaritmisk <https://github.com/logaritmisk>`_

* `v0.6.1 - 16.02.2016 <https://github.com/jedie/django-reversion-compare/compare/v0.6.0...v0.6.1>`_:

    * `pull #61 <https://github.com/jedie/django-reversion-compare/pull/61>`_: Fix error when ManyToMany relations didn't exist contributed by `Diederik van der Boor <https://github.com/vdboor>`_

* `v0.6.0 - 03.02.2016 <https://github.com/jedie/django-reversion-compare/compare/v0.5.6...v0.6.0>`_:

    * Added Dutch translation contributed by `Sae X <https://github.com/SaeX>`_

    * Add support for Django 1.9

    * Nicer boolean compare: `#57 <https://github.com/jedie/django-reversion-compare/issues/57>`_

    * Fix `#58 compare followed reverse foreign relation fields that are on a non-abstract parent class <https://github.com/jedie/django-reversion-compare/issues/58>`_ contributed by `LegoStormtroopr <https://github.com/LegoStormtroopr>`_

* `v0.5.6 - 23.09.2015 <https://github.com/jedie/django-reversion-compare/compare/v0.5.5...v0.5.6>`_:

    * NEW: Class-Based-View to create non-admin views and greek translation contributed by `Serafeim Papastefanos <https://github.com/spapas>`_.

* `v0.5.5 - 24.07.2015 <https://github.com/jedie/django-reversion-compare/compare/v0.5.4...v0.5.5>`_:

    * UnboundLocalError ('version') when creating deleted list in get_many_to_something() `#41 <https://github.com/jedie/django-reversion-compare/pull/41>`_

* `v0.5.4 - 22.07.2015 <https://github.com/jedie/django-reversion-compare/compare/v0.5.3...v0.5.4>`_:

    * One to one field custom related name fix `#42 <https://github.com/jedie/django-reversion-compare/pull/42>`_ (contributed by frwickst and aemdy)

* `v0.5.3 - 13.07.2015 <https://github.com/jedie/django-reversion-compare/compare/v0.5.2...v0.5.3>`_:

    * Update admin.py to avoid RemovedInDjango19Warning (contributed by luzfcb)

* `v0.5.2 - 14.04.2015 <https://github.com/jedie/django-reversion-compare/compare/v0.5.1...v0.5.2>`_:

    * contributed by Samuel Spencer:

        * Added Django 1.8 support: `pull #35 <https://github.com/jedie/django-reversion-compare/pull/35>`_

        * list of changes for reverse fields incorrectly includes a "deletion" for the item that was added in: `issues #34 <https://github.com/jedie/django-reversion-compare/issues/34>`_

* `v0.5.1 - 28.02.2015 <https://github.com/jedie/django-reversion-compare/compare/v0.5.0...v0.5.1>`_:

    * activate previous/next links and add unitests for them

* `v0.5.0 - 27.02.2015 <https://github.com/jedie/django-reversion-compare/compare/v0.4.0...v0.5.0>`_:

    * refactory unittests, test with Django v1.7 and Python 2.7 & 3.4

* `v0.4.0 - 02.02.2015 <https://github.com/jedie/django-reversion-compare/compare/v0.3.5...v0.4.0>`_:

    * Updates for django 1.7 support

    * Add ``settings.ADD_REVERSION_ADMIN``

* v0.3.5 - 03.01.2013:

    * Remove date from version string. `issues 9 <https://github.com/jedie/django-reversion-compare/issues/9>`_

* v0.3.4 - 20.06.2012:

    * Use VersionAdmin.revision_manager rather than default_revision_manager, contributed by Mark Lavin - see: `pull request 7 <https://github.com/jedie/django-reversion-compare/pull/7>`_

    * Use logging for all debug prints, contributed by Bojan Mihelac - see: `pull request 8 <https://github.com/jedie/django-reversion-compare/pull/8>`_

* v0.3.3 - 11.06.2012:

    * Bugfix "ValueError: zero length field name in format" with Python 2.6 `issues 5 <https://github.com/jedie/django-reversion-compare/issues/5>`_

* v0.3.2 - 04.06.2012:

    * Bugfix for Python 2.6 in unified_diff(), see: `AttributeError: 'module' object has no attribute '_format_range_unified' <https://github.com/jedie/django-reversion-compare/issues/5>`_

* v0.3.1 - 01.06.2012:

    * Bugfix: force unicode in html diff

    * Bugfix in unittests

* v0.3.0 - 16.05.2012:

    * Enhanced handling of m2m changes with follow and non-follow relations.

* v0.2.2 - 15.05.2012:

    * Compare many-to-many in the right way.

* v0.2.1 - 10.05.2012:

    * Bugfix for models which has no m2m field: `https://github.com/jedie/django-reversion-compare/commit/c8e042945a6e78e5540b6ae27666f9b0cfc94880 <https://github.com/jedie/django-reversion-compare/commit/c8e042945a6e78e5540b6ae27666f9b0cfc94880>`_

* v0.2.0 - 09.05.2012:

    * many-to-many compare works, too.

* v0.1.0 - 08.05.2012:

    * First release

* v0.0.1 - 08.05.2012:

    * collect all compare stuff from old "diff" branch

    * see also: `https://github.com/etianen/django-reversion/issues/147 <https://github.com/etianen/django-reversion/issues/147>`_

-----
Links
-----

+-----------------+----------------------------------------------------------+
| IRC             | `#pylucid on freenode.net`_                              |
+-----------------+----------------------------------------------------------+
| Github          | `http://github.com/jedie/django-reversion-compare`_      |
+-----------------+----------------------------------------------------------+
| Python Packages | `http://pypi.python.org/pypi/django-reversion-compare/`_ |
+-----------------+----------------------------------------------------------+

.. _#pylucid on freenode.net: http://www.pylucid.org/permalink/304/irc-channel
.. _http://github.com/jedie/django-reversion-compare: http://github.com/jedie/django-reversion-compare
.. _http://pypi.python.org/pypi/django-reversion-compare/: http://pypi.python.org/pypi/django-reversion-compare/

-------
Contact
-------

Come into the conversation, besides the Github communication features:

+---------+--------------------------------------------------------+
| IRC     | #pylucid on freenode.net (Yes, the PyLucid channel...) |
+---------+--------------------------------------------------------+
| webchat | `http://webchat.freenode.net/?channels=pylucid`_       |
+---------+--------------------------------------------------------+

.. _http://webchat.freenode.net/?channels=pylucid: http://webchat.freenode.net/?channels=pylucid

--------
Donation
--------

* `paypal.me/JensDiemer <https://www.paypal.me/JensDiemer>`_

* `Flattr This! <https://flattr.com/submit/auto?uid=jedie&url=https%3A%2F%2Fgithub.com%2Fjedie%2Fdjango-reversion-compare%2F>`_

* Send `Bitcoins <http://www.bitcoin.org/>`_ to `1823RZ5Md1Q2X5aSXRC5LRPcYdveCiVX6F <https://blockexplorer.com/address/1823RZ5Md1Q2X5aSXRC5LRPcYdveCiVX6F>`_

