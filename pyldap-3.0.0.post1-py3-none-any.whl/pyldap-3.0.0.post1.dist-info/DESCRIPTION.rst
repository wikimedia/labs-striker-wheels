-----------------------
THIS FORK IS DEPRECATED
-----------------------

The pyldap fork was merged back into python-ldap,
and released as python-ldap 3.0.0.

Development continues at:

    https://github.com/python-ldap/python-ldap/

Documentation is available at:

    https://python-ldap.org/

To install the new code, use::

    pip install python-ldap

Package pyldap 3.0 now exists only to require python-ldap.

.. warning::

    Unfortunately, due to `pip bug 4961`_, upgrading from previous versions
    using ``pip`` makes the ``ldap`` module unimportable.

    Instead of upgrading, please replace ``pyldap`` by ``python-ldap``
    in two separate steps::

        python -m pip uninstall pyldap
        python -m pip install python-ldap

    If upgraded already issue, you can fix your environment by uninstalling
    and reinstalling ``python-ldap``::

        python -m pip uninstall python-ldap
        python -m pip install python-ldap

    We are sorry for the inconvenience.
    If you have a better solution, please join the discussion at `pyldap bug 148`_.


.. _pip bug 4961: https://github.com/pypa/pip/issues/4961
.. _pyldap bug 148: https://github.com/pyldap/pyldap/issues/148


