__author__ = 'Val Neekman @ Neekware Inc. [@vneekman]'
__description__ = "A Django application to retrieve user's IP address"
__version__ = '1.1.5'

default_app_config = 'ipware.apps.AppConfig'
