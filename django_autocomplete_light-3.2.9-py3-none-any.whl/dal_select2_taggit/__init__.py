"""DAL's Select2 and Taggit extension."""
