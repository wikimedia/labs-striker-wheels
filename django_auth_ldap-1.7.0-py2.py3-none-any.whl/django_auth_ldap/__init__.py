from __future__ import unicode_literals


version = (1, 7, 0)
version_qualifier = ''
version_string = '.'.join(map(str, version)) + version_qualifier
