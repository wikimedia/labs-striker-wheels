__version__ = '2.2'

default_app_config = 'formtools.apps.FormToolsConfig'
