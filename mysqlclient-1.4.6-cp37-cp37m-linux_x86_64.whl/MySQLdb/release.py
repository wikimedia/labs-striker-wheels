
__author__ = "Inada Naoki <songofacandy@gmail.com>"
version_info = (1,4,6,'final',0)
__version__ = "1.4.6"
